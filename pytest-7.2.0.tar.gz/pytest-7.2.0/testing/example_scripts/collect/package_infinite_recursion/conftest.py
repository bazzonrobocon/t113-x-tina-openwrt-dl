def pytest_ignore_collect(collection_path):
    return False
