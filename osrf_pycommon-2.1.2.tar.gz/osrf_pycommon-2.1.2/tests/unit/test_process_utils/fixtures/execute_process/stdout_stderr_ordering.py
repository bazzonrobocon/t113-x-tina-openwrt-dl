from __future__ import print_function

import sys

print("out 1")
print("err 1", file=sys.stderr)
print("out 2")
