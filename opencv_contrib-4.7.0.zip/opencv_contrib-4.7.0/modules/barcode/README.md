1D Barcode Detect and Decode
======================

This module is focused on detecting and decoding barcode from image. It is mainly designed for scanning the images, locating barcode, decoding barcode and outputting its decoded result.

1. Support 1-dimension bar code detection of any angle tilting.
2. Support multi-scale detection.
3. Support EAN-13, EAN-8 and UPC-A decode yet.
4. With x86 CPU, it achieves 50FPS averagely.
