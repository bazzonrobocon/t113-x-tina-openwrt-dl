:orphan:

****************
Memory Alignment
****************

.. This document has been moved to ../dev/alignment.rst.

This document has been moved to :ref:`alignment`.




